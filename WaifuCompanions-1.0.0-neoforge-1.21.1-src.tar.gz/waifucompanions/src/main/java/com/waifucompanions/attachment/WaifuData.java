package com.waifucompanions.attachment;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.core.UUIDUtil;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;

import java.util.*;

/**
 * Persistent data attached to any LivingEntity that has been turned into a waifu companion.
 * All heavy logic is event-driven; this is pure data.
 */
public class WaifuData {
    public static final Codec<WaifuData> CODEC = RecordCodecBuilder.create(inst -> inst.group(
            Codec.BOOL.fieldOf("tamed").forGetter(d -> d.tamed),
            UUIDUtil.CODEC.optionalFieldOf("owner").forGetter(d -> Optional.ofNullable(d.ownerUUID)),
            Codec.STRING.optionalFieldOf("waifuId", "generic").forGetter(d -> d.waifuId),
            Codec.STRING.optionalFieldOf("displayName", "").forGetter(d -> d.displayName),
            Codec.STRING.optionalFieldOf("personality", "kind").forGetter(d -> d.personality),
            Codec.INT.fieldOf("relationshipLevel").forGetter(d -> d.relationshipLevel),
            Codec.INT.fieldOf("affinity").forGetter(d -> d.affinity),
            Codec.INT.fieldOf("trust").forGetter(d -> d.trust),
            Codec.INT.fieldOf("mood").forGetter(d -> d.mood),
            Codec.INT.fieldOf("satiety").forGetter(d -> d.satiety),
            Codec.INT.fieldOf("energy").forGetter(d -> d.energy),
            Codec.INT.fieldOf("experience").forGetter(d -> d.experience),
            Codec.INT.fieldOf("level").forGetter(d -> d.level),
            Codec.LONG.fieldOf("lastInteraction").forGetter(d -> d.lastInteraction),
            Codec.LONG.fieldOf("lastSeenPlayer").forGetter(d -> d.lastSeenPlayer),
            Codec.STRING.listOf().fieldOf("memory").forGetter(d -> d.memory),
            Codec.STRING.listOf().fieldOf("favoriteItems").forGetter(d -> d.favoriteItems),
            Codec.STRING.listOf().fieldOf("dislikedItems").forGetter(d -> d.dislikedItems)
    ).apply(inst, WaifuData::fromCodec));

    public static final StreamCodec<RegistryFriendlyByteBuf, WaifuData> STREAM_CODEC = StreamCodec.composite(
            ByteBufCodecs.BOOL, d -> d.tamed,
            ByteBufCodecs.optional(UUIDUtil.STREAM_CODEC), d -> Optional.ofNullable(d.ownerUUID),
            ByteBufCodecs.STRING_UTF8, d -> d.waifuId,
            ByteBufCodecs.STRING_UTF8, d -> d.displayName,
            ByteBufCodecs.STRING_UTF8, d -> d.personality,
            ByteBufCodecs.VAR_INT, d -> d.relationshipLevel,
            ByteBufCodecs.VAR_INT, d -> d.affinity,
            ByteBufCodecs.VAR_INT, d -> d.trust,
            ByteBufCodecs.VAR_INT, d -> d.mood,
            ByteBufCodecs.VAR_INT, d -> d.satiety,
            ByteBufCodecs.VAR_INT, d -> d.energy,
            ByteBufCodecs.VAR_INT, d -> d.experience,
            ByteBufCodecs.VAR_INT, d -> d.level,
            ByteBufCodecs.VAR_LONG, d -> d.lastInteraction,
            ByteBufCodecs.VAR_LONG, d -> d.lastSeenPlayer,
            ByteBufCodecs.STRING_UTF8.apply(ByteBufCodecs.list()), d -> d.memory,
            ByteBufCodecs.STRING_UTF8.apply(ByteBufCodecs.list()), d -> d.favoriteItems,
            ByteBufCodecs.STRING_UTF8.apply(ByteBufCodecs.list()), d -> d.dislikedItems,
            WaifuData::fromStream
    );

    public boolean tamed;
    public UUID ownerUUID;
    public String waifuId = "generic";
    public String displayName = "";
    public String personality = "kind";
    public int relationshipLevel = 0; // 0..10
    public int affinity = 0;          // 0..1000
    public int trust = 50;            // 0..100
    public int mood = 50;             // 0..100
    public int satiety = 80;          // 0..100
    public int energy = 80;           // 0..100
    public int experience = 0;
    public int level = 1;
    public long lastInteraction = 0;
    public long lastSeenPlayer = 0;
    public List<String> memory = new ArrayList<>();
    public List<String> favoriteItems = new ArrayList<>();
    public List<String> dislikedItems = new ArrayList<>();

    // Transient, not saved
    public transient String currentSticker = null;
    public transient int stickerTicks = 0;
    public transient boolean following = true;
    public transient boolean waiting = false;

    public WaifuData() {}

    private static WaifuData fromCodec(boolean tamed, Optional<UUID> owner, String waifuId, String displayName,
                                       String personality, int rel, int aff, int trust, int mood, int satiety,
                                       int energy, int exp, int level, long lastInt, long lastSeen,
                                       List<String> memory, List<String> fav, List<String> dis) {
        WaifuData d = new WaifuData();
        d.tamed = tamed;
        d.ownerUUID = owner.orElse(null);
        d.waifuId = waifuId;
        d.displayName = displayName;
        d.personality = personality;
        d.relationshipLevel = rel;
        d.affinity = aff;
        d.trust = trust;
        d.mood = mood;
        d.satiety = satiety;
        d.energy = energy;
        d.experience = exp;
        d.level = level;
        d.lastInteraction = lastInt;
        d.lastSeenPlayer = lastSeen;
        d.memory = new ArrayList<>(memory);
        d.favoriteItems = new ArrayList<>(fav);
        d.dislikedItems = new ArrayList<>(dis);
        return d;
    }

    private static WaifuData fromStream(boolean tamed, Optional<UUID> owner, String waifuId, String displayName,
                                        String personality, int rel, int aff, int trust, int mood, int satiety,
                                        int energy, int exp, int level, long lastInt, long lastSeen,
                                        List<String> memory, List<String> fav, List<String> dis) {
        return fromCodec(tamed, owner, waifuId, displayName, personality, rel, aff, trust, mood, satiety,
                energy, exp, level, lastInt, lastSeen, memory, fav, dis);
    }

    public void addMemory(String key) {
        if (!memory.contains(key)) {
            memory.add(key);
            if (memory.size() > 32) {
                memory.remove(0);
            }
        }
    }

    public void addAffinity(int amount) {
        affinity = Math.max(0, Math.min(1000, affinity + amount));
        updateRelationshipLevel();
    }

    public void addTrust(int amount) {
        trust = Math.max(0, Math.min(100, trust + amount));
    }

    public void addMood(int amount) {
        mood = Math.max(0, Math.min(100, mood + amount));
    }

    public void addExperience(int amount) {
        experience += amount;
        while (experience >= expForNextLevel()) {
            experience -= expForNextLevel();
            level++;
        }
    }

    public int expForNextLevel() {
        return 50 + level * 30;
    }

    private void updateRelationshipLevel() {
        relationshipLevel = Math.min(10, affinity / 100);
    }

    public boolean isOwner(UUID uuid) {
        return tamed && ownerUUID != null && ownerUUID.equals(uuid);
    }

    public CompoundTag save() {
        CompoundTag tag = new CompoundTag();
        tag.putBoolean("tamed", tamed);
        if (ownerUUID != null) tag.putUUID("owner", ownerUUID);
        tag.putString("waifuId", waifuId);
        tag.putString("displayName", displayName);
        tag.putString("personality", personality);
        tag.putInt("relationshipLevel", relationshipLevel);
        tag.putInt("affinity", affinity);
        tag.putInt("trust", trust);
        tag.putInt("mood", mood);
        tag.putInt("satiety", satiety);
        tag.putInt("energy", energy);
        tag.putInt("experience", experience);
        tag.putInt("level", level);
        tag.putLong("lastInteraction", lastInteraction);
        tag.putLong("lastSeenPlayer", lastSeenPlayer);
        ListTag mem = new ListTag();
        for (String m : memory) mem.add(StringTag.valueOf(m));
        tag.put("memory", mem);
        ListTag fav = new ListTag();
        for (String f : favoriteItems) fav.add(StringTag.valueOf(f));
        tag.put("favoriteItems", fav);
        ListTag dis = new ListTag();
        for (String d : dislikedItems) dis.add(StringTag.valueOf(d));
        tag.put("dislikedItems", dis);
        return tag;
    }

    public void load(CompoundTag tag) {
        tamed = tag.getBoolean("tamed");
        if (tag.hasUUID("owner")) ownerUUID = tag.getUUID("owner");
        waifuId = tag.getString("waifuId");
        displayName = tag.getString("displayName");
        personality = tag.getString("personality");
        relationshipLevel = tag.getInt("relationshipLevel");
        affinity = tag.getInt("affinity");
        trust = tag.getInt("trust");
        mood = tag.getInt("mood");
        satiety = tag.getInt("satiety");
        energy = tag.getInt("energy");
        experience = tag.getInt("experience");
        level = tag.getInt("level");
        lastInteraction = tag.getLong("lastInteraction");
        lastSeenPlayer = tag.getLong("lastSeenPlayer");
        memory.clear();
        if (tag.contains("memory", Tag.TAG_LIST)) {
            ListTag list = tag.getList("memory", Tag.TAG_STRING);
            for (int i = 0; i < list.size(); i++) memory.add(list.getString(i));
        }
        favoriteItems.clear();
        if (tag.contains("favoriteItems", Tag.TAG_LIST)) {
            ListTag list = tag.getList("favoriteItems", Tag.TAG_STRING);
            for (int i = 0; i < list.size(); i++) favoriteItems.add(list.getString(i));
        }
        dislikedItems.clear();
        if (tag.contains("dislikedItems", Tag.TAG_LIST)) {
            ListTag list = tag.getList("dislikedItems", Tag.TAG_STRING);
            for (int i = 0; i < list.size(); i++) dislikedItems.add(list.getString(i));
        }
    }

    public WaifuData copy() {
        WaifuData d = new WaifuData();
        d.tamed = tamed;
        d.ownerUUID = ownerUUID;
        d.waifuId = waifuId;
        d.displayName = displayName;
        d.personality = personality;
        d.relationshipLevel = relationshipLevel;
        d.affinity = affinity;
        d.trust = trust;
        d.mood = mood;
        d.satiety = satiety;
        d.energy = energy;
        d.experience = experience;
        d.level = level;
        d.lastInteraction = lastInteraction;
        d.lastSeenPlayer = lastSeenPlayer;
        d.memory = new ArrayList<>(memory);
        d.favoriteItems = new ArrayList<>(favoriteItems);
        d.dislikedItems = new ArrayList<>(dislikedItems);
        return d;
    }
}
