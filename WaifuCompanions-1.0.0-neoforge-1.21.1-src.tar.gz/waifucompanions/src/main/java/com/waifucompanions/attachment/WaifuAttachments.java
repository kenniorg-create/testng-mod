package com.waifucompanions.attachment;

import com.waifucompanions.WaifuCompanions;
import net.minecraft.world.entity.LivingEntity;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.attachment.AttachmentType;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.NeoForgeRegistries;

import java.util.Optional;
import java.util.function.Supplier;

public class WaifuAttachments {
    public static final DeferredRegister<AttachmentType<?>> ATTACHMENT_TYPES =
            DeferredRegister.create(NeoForgeRegistries.ATTACHMENT_TYPES, WaifuCompanions.MODID);

    public static final Supplier<AttachmentType<WaifuData>> WAIFU_DATA = ATTACHMENT_TYPES.register(
            "waifu_data",
            () -> AttachmentType.builder(WaifuData::new)
                    .serialize(WaifuData.CODEC)
                    .copyOnDeath()
                    .build()
    );

    public static void register(IEventBus bus) {
        ATTACHMENT_TYPES.register(bus);
    }

    public static Optional<WaifuData> get(LivingEntity entity) {
        return Optional.ofNullable(entity.getExistingData(WAIFU_DATA.get()));
    }

    public static WaifuData getOrCreate(LivingEntity entity) {
        return entity.getData(WAIFU_DATA.get());
    }

    public static boolean has(LivingEntity entity) {
        return entity.hasData(WAIFU_DATA.get()) && get(entity).map(d -> d.tamed).orElse(false);
    }
}
