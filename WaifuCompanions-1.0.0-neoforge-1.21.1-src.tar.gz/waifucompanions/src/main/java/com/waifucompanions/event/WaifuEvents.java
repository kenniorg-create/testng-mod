package com.waifucompanions.event;

import com.waifucompanions.WaifuCompanions;
import com.waifucompanions.attachment.WaifuAttachments;
import com.waifucompanions.attachment.WaifuData;
import com.waifucompanions.data.WaifuDataManager;
import com.waifucompanions.data.WaifuDefinition;
import com.waifucompanions.sticker.StickerManager;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.entity.living.LivingDeathEvent;
import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent;
import net.neoforged.neoforge.event.tick.EntityTickEvent;

import java.util.Random;
import java.util.UUID;

public class WaifuEvents {
    private static final Random RANDOM = new Random();

    @SubscribeEvent
    public static void onEntityInteract(PlayerInteractEvent.EntityInteract event) {
        if (event.getLevel().isClientSide()) return;
        if (!(event.getTarget() instanceof LivingEntity living)) return;
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        if (event.getHand() != InteractionHand.MAIN_HAND) return;

        ItemStack held = player.getItemInHand(InteractionHand.MAIN_HAND);

        // Shift + right click with empty hand or special item to open menu / talk
        if (player.isShiftKeyDown()) {
            WaifuData data = WaifuAttachments.getOrCreate(living);
            if (data.tamed && data.isOwner(player.getUUID())) {
                // Open interaction (for now send status + dialogue)
                handleTalk(player, living, data);
                event.setCanceled(true);
                event.setCancellationResult(InteractionResult.SUCCESS);
                return;
            }
        }

        // Taming attempt: right-click with golden apple or special item on untamed mob
        if (!WaifuAttachments.has(living) && isTamingItem(held)) {
            tryTame(player, living, held);
            event.setCanceled(true);
            event.setCancellationResult(InteractionResult.SUCCESS);
            return;
        }

        // Feed / gift if already tamed
        if (WaifuAttachments.has(living)) {
            WaifuData data = WaifuAttachments.get(living).orElseThrow();
            if (data.isOwner(player.getUUID())) {
                if (held.isEmpty()) {
                    handlePet(player, living, data);
                } else {
                    handleGiftOrFeed(player, living, data, held);
                }
                event.setCanceled(true);
                event.setCancellationResult(InteractionResult.SUCCESS);
            }
        }
    }

    private static boolean isTamingItem(ItemStack stack) {
        return stack.is(Items.GOLDEN_APPLE) || stack.is(Items.ENCHANTED_GOLDEN_APPLE) || stack.is(Items.GOLDEN_CARROT);
    }

    private static void tryTame(ServerPlayer player, LivingEntity living, ItemStack held) {
        // Simple chance based on item
        float chance = held.is(Items.ENCHANTED_GOLDEN_APPLE) ? 1.0f : 0.4f;
        if (RANDOM.nextFloat() > chance) {
            player.displayClientMessage(Component.literal("§cНе удалось приручить..."), true);
            if (!player.getAbilities().instabuild) held.shrink(1);
            return;
        }

        if (!player.getAbilities().instabuild) held.shrink(1);

        WaifuData data = WaifuAttachments.getOrCreate(living);
        data.tamed = true;
        data.ownerUUID = player.getUUID();
        data.waifuId = "generic";
        data.displayName = living.getName().getString();
        data.personality = pickRandomPersonality();
        data.affinity = 50;
        data.trust = 40;
        data.mood = 60;
        data.satiety = 70;
        data.energy = 80;
        data.level = 1;
        data.lastInteraction = living.level().getGameTime();
        data.lastSeenPlayer = living.level().getGameTime();

        WaifuDefinition def = WaifuDataManager.get(data.waifuId);
        data.favoriteItems.addAll(def.favoriteItems);
        data.dislikedItems.addAll(def.dislikedItems);

        // Make friendly if Mob
        if (living instanceof Mob mob) {
            mob.setTarget(null);
            // Basic follow AI can be added later via goals
        }

        living.setCustomName(Component.literal("§d" + data.displayName));
        living.setCustomNameVisible(true);

        playDialogue(player, living, data, "tamed");
        StickerManager.show(living, "❤️", 60);
        player.displayClientMessage(Component.literal("§aВы приручили " + data.displayName + "!"), false);
        WaifuCompanions.LOGGER.info("Player {} tamed {} as waifu", player.getName().getString(), living.getName().getString());
    }

    private static String pickRandomPersonality() {
        String[] p = {"kind", "shy", "bold", "cheerful", "lazy", "aggressive", "caring", "jealous", "serious"};
        return p[RANDOM.nextInt(p.length)];
    }

    private static void handleTalk(ServerPlayer player, LivingEntity living, WaifuData data) {
        data.lastInteraction = living.level().getGameTime();
        data.lastSeenPlayer = living.level().getGameTime();

        long timeAway = living.level().getGameTime() - data.lastSeenPlayer;
        // Note: lastSeen is updated, so for demo we use a simple check

        String event = "talk";
        if (data.mood < 30) event = "low_mood";
        else if (data.mood > 80) event = "high_mood";

        // Check time of day / weather simply
        Level level = living.level();
        if (level.isRaining()) event = "rain";
        else if (level.isNight()) event = "night";

        playDialogue(player, living, data, event);
        data.addExperience(2);
        data.addMood(2);
    }

    private static void handlePet(ServerPlayer player, LivingEntity living, WaifuData data) {
        data.lastInteraction = living.level().getGameTime();
        playDialogue(player, living, data, "pet");
        data.addAffinity(5);
        data.addMood(5);
        data.addExperience(1);
        StickerManager.show(living, "💕", 40);
    }

    private static void handleGiftOrFeed(ServerPlayer player, LivingEntity living, WaifuData data, ItemStack stack) {
        String itemId = stack.getItem().builtInRegistryHolder().key().location().toString();
        data.lastInteraction = living.level().getGameTime();

        boolean liked = data.favoriteItems.contains(itemId) || data.favoriteItems.stream().anyMatch(itemId::contains);
        boolean disliked = data.dislikedItems.contains(itemId) || data.dislikedItems.stream().anyMatch(itemId::contains);

        if (!player.getAbilities().instabuild) stack.shrink(1);

        if (liked) {
            playDialogue(player, living, data, "gift_liked");
            data.addAffinity(15);
            data.addTrust(5);
            data.addMood(10);
            data.satiety = Math.min(100, data.satiety + 20);
            data.addMemory("gift_" + itemId);
            StickerManager.show(living, "❤️", 50);
        } else if (disliked) {
            playDialogue(player, living, data, "gift_disliked");
            data.addAffinity(-10);
            data.addMood(-10);
            StickerManager.show(living, "💢", 40);
        } else {
            // Neutral food
            data.satiety = Math.min(100, data.satiety + 10);
            data.addMood(3);
            data.addAffinity(3);
            player.displayClientMessage(Component.literal("§7" + data.displayName + " принял(а) подарок."), true);
            StickerManager.show(living, "😊", 30);
        }
        data.addExperience(3);
    }

    public static void playDialogue(ServerPlayer player, LivingEntity living, WaifuData data, String event) {
        WaifuDefinition def = WaifuDataManager.get(data.waifuId);
        def.pickDialogue(event, data.relationshipLevel, RANDOM).ifPresent(entry -> {
            String text = "§d[" + data.displayName + "]§r " + entry.text();
            player.displayClientMessage(Component.literal(text), false);
            if (entry.sticker() != null) {
                StickerManager.show(living, entry.sticker(), 50);
            }
        });
    }

    @SubscribeEvent
    public static void onEntityTick(EntityTickEvent.Post event) {
        if (!(event.getEntity() instanceof LivingEntity living)) return;
        if (living.level().isClientSide()) return;
        if (!WaifuAttachments.has(living)) return;

        WaifuData data = WaifuAttachments.get(living).orElseThrow();

        // Sticker lifetime
        if (data.stickerTicks > 0) {
            data.stickerTicks--;
            if (data.stickerTicks <= 0) data.currentSticker = null;
        }

        // Rare passive checks every 100 ticks (~5 sec)
        if (living.tickCount % 100 == 0) {
            // Decay satiety / energy slowly
            if (data.satiety > 0 && RANDOM.nextInt(5) == 0) data.satiety--;
            if (data.energy > 0 && RANDOM.nextInt(8) == 0) data.energy--;

            // Mood affected by satiety
            if (data.satiety < 20) data.addMood(-2);
            if (data.energy < 20) data.addMood(-1);

            // Follow owner if following flag
            if (data.following && !data.waiting && data.ownerUUID != null && living instanceof Mob mob) {
                Player owner = living.level().getPlayerByUUID(data.ownerUUID);
                if (owner != null && living.distanceToSqr(owner) > 16.0 && living.distanceToSqr(owner) < 1024.0) {
                    // Simple teleport if too far, otherwise pathing would need custom goal
                    if (living.distanceToSqr(owner) > 256.0) {
                        living.teleportTo(owner.getX(), owner.getY(), owner.getZ());
                    }
                }
            }
        }
    }

    @SubscribeEvent
    public static void onDeath(LivingDeathEvent event) {
        if (!(event.getEntity() instanceof LivingEntity living)) return;
        if (!WaifuAttachments.has(living)) return;
        WaifuData data = WaifuAttachments.get(living).orElseThrow();
        if (data.ownerUUID != null) {
            Player owner = living.level().getPlayerByUUID(data.ownerUUID);
            if (owner instanceof ServerPlayer sp) {
                sp.displayClientMessage(Component.literal("§c" + data.displayName + " погиб(ла)..."), false);
            }
        }
    }
}
