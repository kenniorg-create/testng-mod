package com.waifucompanions.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.waifucompanions.attachment.WaifuAttachments;
import com.waifucompanions.attachment.WaifuData;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;

public class WaifuCommands {
    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        dispatcher.register(Commands.literal("waifu")
                .requires(s -> s.hasPermission(2))
                .then(Commands.literal("status")
                        .then(Commands.argument("entity", EntityArgument.entity())
                                .executes(ctx -> {
                                    Entity e = EntityArgument.getEntity(ctx, "entity");
                                    if (!(e instanceof LivingEntity living)) {
                                        ctx.getSource().sendFailure(Component.literal("Not a living entity"));
                                        return 0;
                                    }
                                    WaifuData data = WaifuAttachments.get(living).orElse(null);
                                    if (data == null || !data.tamed) {
                                        ctx.getSource().sendFailure(Component.literal("Not a waifu"));
                                        return 0;
                                    }
                                    ctx.getSource().sendSuccess(() -> Component.literal(
                                            "§d" + data.displayName + "§r | Lvl " + data.level +
                                                    " | Rel " + data.relationshipLevel +
                                                    " | Aff " + data.affinity +
                                                    " | Mood " + data.mood +
                                                    " | Trust " + data.trust +
                                                    " | Personality: " + data.personality
                                    ), false);
                                    return 1;
                                })))
                .then(Commands.literal("tame")
                        .then(Commands.argument("entity", EntityArgument.entity())
                                .executes(ctx -> {
                                    Entity e = EntityArgument.getEntity(ctx, "entity");
                                    if (!(e instanceof LivingEntity living) || !(ctx.getSource().getEntity() instanceof ServerPlayer player)) {
                                        return 0;
                                    }
                                    WaifuData data = WaifuAttachments.getOrCreate(living);
                                    data.tamed = true;
                                    data.ownerUUID = player.getUUID();
                                    data.displayName = living.getName().getString();
                                    data.personality = "kind";
                                    living.setCustomName(Component.literal("§d" + data.displayName));
                                    living.setCustomNameVisible(true);
                                    ctx.getSource().sendSuccess(() -> Component.literal("Tamed!"), true);
                                    return 1;
                                })))
        );
    }
}
