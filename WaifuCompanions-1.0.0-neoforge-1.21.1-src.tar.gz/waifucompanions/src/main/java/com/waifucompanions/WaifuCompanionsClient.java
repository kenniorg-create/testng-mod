package com.waifucompanions;

import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;

@Mod(value = WaifuCompanions.MODID, dist = Dist.CLIENT)
public class WaifuCompanionsClient {
    public WaifuCompanionsClient(IEventBus modEventBus, ModContainer container) {
        // Client-side: future floating sticker renderer, GUI screens etc.
        // Currently stickers use server-side action bar for maximum compatibility and zero TPS impact.
    }
}
