package com.waifucompanions.sticker;

import com.waifucompanions.attachment.WaifuAttachments;
import com.waifucompanions.attachment.WaifuData;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;

/**
 * Lightweight sticker system: shows emoji above entity via action bar / chat for nearby players
 * and stores transient state. For full visual floating stickers a client-side particle/renderer
 * would be added later without heavy tick cost.
 */
public class StickerManager {
    public static void show(LivingEntity entity, String emoji, int durationTicks) {
        WaifuData data = WaifuAttachments.get(entity).orElse(null);
        if (data == null) return;
        data.currentSticker = emoji;
        data.stickerTicks = durationTicks;

        if (entity.level() instanceof ServerLevel level) {
            // Notify nearby players with a short message (lightweight)
            for (ServerPlayer p : level.players()) {
                if (p.distanceToSqr(entity) < 64 * 64) {
                    p.displayClientMessage(Component.literal(emoji + " " + entity.getName().getString()), true);
                }
            }
        }
    }
}
