package com.waifucompanions;

import com.mojang.logging.LogUtils;
import com.waifucompanions.attachment.WaifuAttachments;
import com.waifucompanions.command.WaifuCommands;
import com.waifucompanions.data.WaifuDataManager;
import com.waifucompanions.event.WaifuEvents;
import com.waifucompanions.network.WaifuNetwork;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.event.lifecycle.FMLCommonSetupEvent;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.RegisterCommandsEvent;
import org.slf4j.Logger;

@Mod(WaifuCompanions.MODID)
public class WaifuCompanions {
    public static final String MODID = "waifucompanions";
    public static final Logger LOGGER = LogUtils.getLogger();

    public WaifuCompanions(IEventBus modEventBus, ModContainer modContainer) {
        modEventBus.addListener(this::commonSetup);

        WaifuAttachments.register(modEventBus);
        WaifuNetwork.register(modEventBus);

        NeoForge.EVENT_BUS.register(WaifuEvents.class);
        NeoForge.EVENT_BUS.addListener(this::onRegisterCommands);

        LOGGER.info("Waifu Companions mod initialized");
    }

    private void commonSetup(FMLCommonSetupEvent event) {
        event.enqueueWork(() -> {
            WaifuDataManager.loadAll();
            LOGGER.info("Loaded {} waifu definitions", WaifuDataManager.getAll().size());
        });
    }

    private void onRegisterCommands(RegisterCommandsEvent event) {
        WaifuCommands.register(event.getDispatcher());
    }
}
