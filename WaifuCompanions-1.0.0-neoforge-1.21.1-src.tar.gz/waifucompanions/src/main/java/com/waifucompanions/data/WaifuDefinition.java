package com.waifucompanions.data;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.util.*;

/**
 * Data-driven definition loaded from JSON under data/waifucompanions/waifus/
 */
public class WaifuDefinition {
    public final String id;
    public final String name;
    public final String personality;
    public final Map<String, Integer> baseStats = new HashMap<>();
    public final List<String> favoriteItems = new ArrayList<>();
    public final List<String> dislikedItems = new ArrayList<>();
    public final Map<String, List<DialogueEntry>> dialogues = new HashMap<>();
    public final Map<String, List<String>> stickers = new HashMap<>();
    public final List<String> abilities = new ArrayList<>();

    public WaifuDefinition(String id, String name, String personality) {
        this.id = id;
        this.name = name;
        this.personality = personality;
    }

    public static WaifuDefinition fromJson(String id, JsonObject json) {
        String name = json.has("name") ? json.get("name").getAsString() : id;
        String personality = json.has("personality") ? json.get("personality").getAsString() : "kind";
        WaifuDefinition def = new WaifuDefinition(id, name, personality);

        if (json.has("baseStats")) {
            JsonObject stats = json.getAsJsonObject("baseStats");
            for (String key : stats.keySet()) {
                def.baseStats.put(key, stats.get(key).getAsInt());
            }
        }
        if (json.has("favoriteItems")) {
            for (JsonElement e : json.getAsJsonArray("favoriteItems")) {
                def.favoriteItems.add(e.getAsString());
            }
        }
        if (json.has("dislikedItems")) {
            for (JsonElement e : json.getAsJsonArray("dislikedItems")) {
                def.dislikedItems.add(e.getAsString());
            }
        }
        if (json.has("dialogues")) {
            JsonObject dlg = json.getAsJsonObject("dialogues");
            for (String event : dlg.keySet()) {
                List<DialogueEntry> list = new ArrayList<>();
                JsonArray arr = dlg.getAsJsonArray(event);
                for (JsonElement el : arr) {
                    if (el.isJsonObject()) {
                        JsonObject o = el.getAsJsonObject();
                        String text = o.get("text").getAsString();
                        int minRel = o.has("minRel") ? o.get("minRel").getAsInt() : 0;
                        int maxRel = o.has("maxRel") ? o.get("maxRel").getAsInt() : 10;
                        String sticker = o.has("sticker") ? o.get("sticker").getAsString() : null;
                        list.add(new DialogueEntry(text, minRel, maxRel, sticker));
                    } else {
                        list.add(new DialogueEntry(el.getAsString(), 0, 10, null));
                    }
                }
                def.dialogues.put(event, list);
            }
        }
        if (json.has("stickers")) {
            JsonObject st = json.getAsJsonObject("stickers");
            for (String key : st.keySet()) {
                List<String> list = new ArrayList<>();
                for (JsonElement e : st.getAsJsonArray(key)) {
                    list.add(e.getAsString());
                }
                def.stickers.put(key, list);
            }
        }
        if (json.has("abilities")) {
            for (JsonElement e : json.getAsJsonArray("abilities")) {
                def.abilities.add(e.getAsString());
            }
        }
        return def;
    }

    public Optional<DialogueEntry> pickDialogue(String event, int relationshipLevel, Random random) {
        List<DialogueEntry> list = dialogues.get(event);
        if (list == null || list.isEmpty()) return Optional.empty();
        List<DialogueEntry> filtered = list.stream()
                .filter(d -> relationshipLevel >= d.minRel && relationshipLevel <= d.maxRel)
                .toList();
        if (filtered.isEmpty()) return Optional.empty();
        return Optional.of(filtered.get(random.nextInt(filtered.size())));
    }

    public String pickSticker(String emotion, Random random) {
        List<String> list = stickers.getOrDefault(emotion, List.of(emotion));
        if (list.isEmpty()) return emotion;
        return list.get(random.nextInt(list.size()));
    }

    public record DialogueEntry(String text, int minRel, int maxRel, String sticker) {}
}
