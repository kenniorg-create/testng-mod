package com.waifucompanions.data;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.waifucompanions.WaifuCompanions;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.resources.Resource;
import net.minecraft.server.packs.resources.ResourceManager;
import net.neoforged.neoforge.server.ServerLifecycleHooks;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.*;

public class WaifuDataManager {
    private static final Map<String, WaifuDefinition> DEFINITIONS = new HashMap<>();
    private static final WaifuDefinition GENERIC;

    static {
        GENERIC = new WaifuDefinition("generic", "Companion", "kind");
        GENERIC.baseStats.put("trust", 50);
        GENERIC.baseStats.put("mood", 50);
        GENERIC.favoriteItems.add("minecraft:apple");
        GENERIC.favoriteItems.add("minecraft:sweet_berries");
        GENERIC.dislikedItems.add("minecraft:rotten_flesh");
        // Default dialogues
        GENERIC.dialogues.put("first_meet", List.of(
                new WaifuDefinition.DialogueEntry("...Кто ты?", 0, 10, "❓"),
                new WaifuDefinition.DialogueEntry("Ты... не выглядишь опасным.", 0, 10, "😳")
        ));
        GENERIC.dialogues.put("tamed", List.of(
                new WaifuDefinition.DialogueEntry("Я... буду с тобой.", 0, 10, "❤️"),
                new WaifuDefinition.DialogueEntry("Хорошо. Я доверюсь тебе.", 0, 10, "💕")
        ));
        GENERIC.dialogues.put("talk", List.of(
                new WaifuDefinition.DialogueEntry("Как дела?", 0, 3, "😊"),
                new WaifuDefinition.DialogueEntry("Ты всегда рядом... мне нравится.", 4, 10, "💕"),
                new WaifuDefinition.DialogueEntry("Сегодня хороший день!", 0, 10, "😊")
        ));
        GENERIC.dialogues.put("pet", List.of(
                new WaifuDefinition.DialogueEntry("Ммм...", 0, 10, "😊"),
                new WaifuDefinition.DialogueEntry("Ещё...", 3, 10, "💕")
        ));
        GENERIC.dialogues.put("gift_liked", List.of(
                new WaifuDefinition.DialogueEntry("Спасибо! Мне это нравится!", 0, 10, "❤️")
        ));
        GENERIC.dialogues.put("gift_disliked", List.of(
                new WaifuDefinition.DialogueEntry("...Это не очень.", 0, 10, "💢")
        ));
        GENERIC.dialogues.put("return_long", List.of(
                new WaifuDefinition.DialogueEntry("Ты вернулся... Я ждала.", 0, 10, "😢"),
                new WaifuDefinition.DialogueEntry("Где ты был так долго?!", 2, 10, "😡")
        ));
        GENERIC.dialogues.put("low_mood", List.of(
                new WaifuDefinition.DialogueEntry("...Мне грустно.", 0, 10, "😢")
        ));
        GENERIC.dialogues.put("high_mood", List.of(
                new WaifuDefinition.DialogueEntry("Я так счастлива!", 0, 10, "😊")
        ));
        GENERIC.dialogues.put("level_up", List.of(
                new WaifuDefinition.DialogueEntry("Я стала сильнее... благодаря тебе.", 0, 10, "❗")
        ));
        GENERIC.dialogues.put("night", List.of(
                new WaifuDefinition.DialogueEntry("Ночь... будь осторожен.", 0, 10, "😴")
        ));
        GENERIC.dialogues.put("rain", List.of(
                new WaifuDefinition.DialogueEntry("Дождь... давай найдём укрытие.", 0, 10, "💦")
        ));
        DEFINITIONS.put("generic", GENERIC);
    }

    public static void loadAll() {
        // Built-in already loaded. Additional JSONs will be loaded when server starts via resource reload if needed.
        // For simplicity we keep in-memory + allow runtime JSON from data pack path.
        try {
            if (ServerLifecycleHooks.getCurrentServer() != null) {
                ResourceManager rm = ServerLifecycleHooks.getCurrentServer().getResourceManager();
                Map<ResourceLocation, Resource> resources = rm.listResources("waifus", loc -> loc.getPath().endsWith(".json"));
                for (Map.Entry<ResourceLocation, Resource> entry : resources.entrySet()) {
                    if (!entry.getKey().getNamespace().equals(WaifuCompanions.MODID)) continue;
                    String path = entry.getKey().getPath();
                    String id = path.substring("waifus/".length(), path.length() - 5);
                    try (BufferedReader reader = new BufferedReader(new InputStreamReader(entry.getValue().open(), StandardCharsets.UTF_8))) {
                        JsonObject json = JsonParser.parseReader(reader).getAsJsonObject();
                        WaifuDefinition def = WaifuDefinition.fromJson(id, json);
                        DEFINITIONS.put(id, def);
                        WaifuCompanions.LOGGER.info("Loaded waifu definition: {}", id);
                    } catch (Exception e) {
                        WaifuCompanions.LOGGER.error("Failed to load waifu {}", id, e);
                    }
                }
            }
        } catch (Exception e) {
            WaifuCompanions.LOGGER.warn("Could not load external waifu JSONs yet: {}", e.getMessage());
        }
    }

    public static WaifuDefinition get(String id) {
        return DEFINITIONS.getOrDefault(id, GENERIC);
    }

    public static Collection<WaifuDefinition> getAll() {
        return DEFINITIONS.values();
    }

    public static void register(WaifuDefinition def) {
        DEFINITIONS.put(def.id, def);
    }
}
