package com.waifucompanions.network;

import com.waifucompanions.WaifuCompanions;
import net.neoforged.bus.api.IEventBus;

public class WaifuNetwork {
    public static void register(IEventBus bus) {
        // Placeholder for future packets (open GUI, sync sticker, etc.)
        // Using simple server->client messages via existing chat for now to keep TPS high.
    }
}
